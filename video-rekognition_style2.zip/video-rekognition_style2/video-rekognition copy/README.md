# video-rekognition
Coursera Guided Project - Video Indexing
